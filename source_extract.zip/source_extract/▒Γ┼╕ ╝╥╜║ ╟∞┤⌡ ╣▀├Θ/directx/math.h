#ifndef _SAMPLE_MATH_H_
#define _SAMPLE_MATH_H_

#include "Core_Graphics.h"
using namespace core::graphics;

#include "Core_Input.h"
using namespace core::input;

#include "Core_System.h"
using namespace core::system;

namespace sample {
	namespace math {
		void RotationByMouse(void *Ptr, long Purpose);
		void Triangle(void *Ptr, long Purpose);
		void CircleCollision(void *Ptr, long Purpose);
		void DotPlaneCollision(void *Ptr, long Purpose);
		void MatrixVector(void *Ptr, long Purpose);
	}
}

#endif