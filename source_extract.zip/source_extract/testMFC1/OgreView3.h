// OgreView.h : interface of the COgreView class
//


#pragma once

#include "testOgreListener.h"

class COgreDoc;

class COgreView3 : public CView
{
	myOgre::testOgreFrameListener listener;

protected: // create from serialization only
	COgreView3();
	DECLARE_DYNCREATE(COgreView3)

//// Attributes
//public:
//	COgreDoc* GetDocument() const;

// Operations
public:


// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// Implementation
public:
	virtual ~COgreView3();

#if 0
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	virtual void OnInitialUpdate();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

#if 0
#ifndef _DEBUG  // debug version in OgreView.cpp
inline COgreDoc* COgreView::GetDocument() const
   { return reinterpret_cast<COgreDoc*>(m_pDocument); }
#endif
#endif
