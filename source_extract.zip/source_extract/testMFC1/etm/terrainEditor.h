#ifndef __terrainEditor_h_
#define __terrainEditor_h_

//#include "./baseApp/BaseApplication.h"
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
//#include "../res/resource.h"
#endif

#include <CEGUI/CEGUI.h>
#include <CEGUI/CEGUISystem.h>
#include <CEGUI/CEGUISchemeManager.h>
#include <OgreCEGUIRenderer.h>

#include "ETTerrainManager.h"
#include "ETTerrainInfo.h"
#include "ETBrush.h"
#include "ETSplattingManager.h"

using namespace std;
using Ogre::uint;

#include <vector>

#include "objectParser.h"

#include <ogre.h>
#include <OgreStringConverter.h>
#include <OgreException.h>

//Use this define to signify OIS will be used as a DLL
//(so that dll import/export macros are in effect)
#define OIS_DYNAMIC_LIB
#include <OIS/OIS.h>

class BaseApplication : public FrameListener, public WindowEventListener, public OIS::KeyListener, public OIS::MouseListener
{
public:
	BaseApplication(void) {};
	virtual ~BaseApplication(void) {};

///	virtual void go(void) = 0;

protected:
//	virtual bool setup() = 0;
//	virtual bool configure(void) = 0;
	virtual void chooseSceneManager(void) = 0;
	virtual void createCamera(void) = 0;
	virtual void createFrameListener(void) = 0;
	virtual void createScene(void) = 0; // Override me!
	virtual void destroyScene(void) = 0;
	virtual void createViewports(void) = 0;
//	virtual void setupResources(void) = 0;
//	virtual void createResourceListener(void) = 0;
//	virtual void loadResources(void) = 0;
//	virtual void updateStats(void) = 0;
	virtual bool processUnbufferedKeyInput(const FrameEvent& evt) = 0;
	virtual bool processUnbufferedMouseInput(const FrameEvent& evt) = 0;
	virtual void moveCamera() = 0;
//	virtual bool frameRenderingQueued(const FrameEvent& evt) = 0; // added from exampleframelistener.
	virtual bool frameStarted(const FrameEvent& evt) = 0; // to comments by frameRenderingQueued().
	virtual bool frameEnded(const FrameEvent& evt) = 0;

//	void showDebugOverlay(bool show) = 0;
//	void switchMouseMode() = 0;
//	void switchKeyMode() = 0;
	virtual bool keyPressed( const OIS::KeyEvent &arg ) = 0;
	virtual bool keyReleased( const OIS::KeyEvent &arg ) = 0;
	virtual bool mouseMoved( const OIS::MouseEvent &arg ) = 0;
	virtual bool mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id ) = 0;
	virtual bool mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id ) = 0;

	//Adjust mouse clipping area
//	virtual void windowResized(RenderWindow* rw) = 0;
	//Unattach OIS before window shutdown (very important under Linux)
//	virtual void windowClosed(RenderWindow* rw) = 0;


	float mSpeedLimit; // for camera move in renderingQueued().
	Real mCurrentSpeed; // for camera move in renderingQueued().

public:
	Root *mRoot;
protected:
	Camera* mCamera;
	SceneManager* mSceneMgr;
	RenderWindow* mWindow;
	int mSceneDetailIndex ;
	Real mMoveSpeed;
	Degree mRotateSpeed;
	Overlay* mDebugOverlay;
	std::string mDebugText;
	//OIS Input devices
	OIS::InputManager* mInputManager;
	OIS::Mouse*    mMouse;
	OIS::Keyboard* mKeyboard;
	Vector3 mTranslateVector;
	bool mStatsOn;
	bool mUseBufferedInputKeys, mUseBufferedInputMouse, mInputTypeSwitchingOn;
	unsigned int mNumScreenShots;
	float mMoveScale;
	Degree mRotScale;
	Real mTimeUntilNextToggle; // just to stop toggles flipping too fast
	Radian mRotX, mRotY;
	TextureFilterOptions mFiltering;
	int mAniso;
};

class terrainEditor : public BaseApplication
//class terrainEditor : public FrameListener, public WindowEventListener, public OIS::KeyListener, public OIS::MouseListener
{
	bool firstframe;

	CEGUI::MouseButton convertOISMouseButtonToCegui(int buttonID)
	{
		switch (buttonID)
		{
		case 0: return CEGUI::LeftButton;
		case 1: return CEGUI::RightButton;
		case 2:	return CEGUI::MiddleButton;
		case 3: return CEGUI::X1Button;
		default: return CEGUI::LeftButton;
		}
	}

public:
	terrainEditor(void);
	virtual ~terrainEditor(void);

	// common

	// etm
private:
	ET::TerrainManager* mTerrainMgr;
	ET::SplattingManager* mSplatMgr;

protected:
	//	CEGUI::Renderer *mGUIRenderer;     // cegui renderer
	CEGUI::OgreCEGUIRenderer *mGUIRenderer;

	// app

protected:
	CEGUI::System *mGUISystem;         // cegui system
	RaySceneQuery* raySceneQuery;

protected:
	virtual void chooseSceneManager(void);
	virtual void createViewports(void);
	virtual void createCamera(void);
	virtual void createFrameListener();
	virtual void createScene(void);
	virtual void destroyScene(void) {};

//	bool handleQuit(const CEGUI::EventArgs& e);

	// listener
private:
	bool key_state_map;

	float mHeightIntensity;
public:
	void setHeightIntensity(float height_intensity) { mHeightIntensity = height_intensity; }
	void ChangeBrushSize( int PointSize , int BrushSize)
	{
		float fBrushSize = (float)BrushSize * 2;
		float fPointSize = (float)PointSize * 0.5;

		Vector3 vec = mPointer->getScale();
//		mPointer->setScale(vec.x+fPointSize, vec.y, vec.z+fPointSize);

		Image image;
		image.load("brush.png", "ET");
		image.resize(8+fBrushSize, 8+fBrushSize);
		mEditBrush = ET::loadBrushFromImage(image);

	}
	string strObjName;

	// etm
protected:
	RaySceneQuery *mRaySceneQueryET;     // The ray scene query pointer
	bool mLMouseDownET, mRMouseDownET;     // True if the mouse buttons are down
	bool mMMouseDownET;
//	SceneManager *mSceneMgr;           // A pointer to the scene manager
	SceneNode *mPointer;               // Our "pointer" on the terrain
	ET::Brush mEditBrush;              // Brush for terrain editing
	bool mDeform;                      // stores which mode we are in (deform or paint)
	uint mChosenTexture;                // which of the four splatting textures is to be used?

	// movement
	Vector3 mDirectionET;
	bool mMove;

	SceneNode* mCamNode;

	bool mContinue;

	RaySceneQuery *mRaySceneQueryETM;

	const ET::TerrainInfo* mTerrainInfo;

protected:
	worldT world;
	vector<objectT> object_list;
	objectParser object_parser;
	void saveTerrain();
	void loadTerrain(float size_x, float size_y, float heightmap);

	void createEditBrush();
	void updateLightmap();

	// testOgre
private:
	AnimationState *ani;

	std::deque<Vector3> mWalkList;
	float mWalkSpeed, mDistance;
	Vector3 mDestination, mDirection;

 	RaySceneQuery *mRaySceneQuery;
 	Ray mouseRay;
 	SceneNode *mCurrentObject;
	int mCurrentOp;
	int mCount;
protected:
	bool mLMouseDown, mRMouseDown;
	bool mMMouseDown;

protected:
	void moveCamera();

//	bool frameRenderingQueued(const FrameEvent& evt);
	virtual bool frameStarted(const Ogre::FrameEvent& evt);
	virtual bool frameEnded(const Ogre::FrameEvent& evt);
//	void requestShutdown(void);

	virtual bool processUnbufferedMouseInput(const FrameEvent& evt);
	bool processUnbufferedKeyInput(const FrameEvent& evt);
	virtual bool mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id );
	virtual bool mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id );
	virtual bool mouseMoved( const OIS::MouseEvent &arg );
	virtual bool keyPressed(const OIS::KeyEvent& arg);
	virtual bool keyReleased(const OIS::KeyEvent& arg);

public:
	bool event_message(MSG* pMsg);
};

#endif
