#ifndef _SAMPLE_GRAPHICS_H_
#define _SAMPLE_GRAPHICS_H_

#include "Core_Graphics.h"
using namespace core::graphics;

#include "Core_Input.h"
using namespace core::input;

#include "Core_System.h"
using namespace core::system;

namespace sample {
	namespace graphics {
		namespace Image {
			class spriteInfo;
			class spriteInfoMultiple;
			class spriteInfoRegion;
			class spriteInfoConstant;
			BOOL CALLBACK RemoteDlgProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
			BOOL CALLBACK InfoDlgProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
			void SpriteTool(void *Ptr, long Purpose);
		}

		namespace Device {
			void ZBuffer(void *Ptr, long Purpose);
		}

		namespace Font {
			void Font(void *Ptr, long Purpose);
			void Font2(void *Ptr, long Purpose);
		}

		namespace Geometry {
			void Line2D(void *Ptr, long Purpose);
			void Line3D(void *Ptr, long Purpose);
			void Draw2D(void *Ptr, long Purpose);
			void Draw3D(void *Ptr, long Purpose);
		}

		namespace Effects {
			void Alpha(void *Ptr, long Purpose);
			void Billboard(void *Ptr, long Purpose);
			void Lights(void *Ptr, long Purpose);
			void Particles(void *Ptr, long Purpose);
		}

		namespace Transform {
			void Transform2D(void *Ptr, long Purpose);
			void Transform(void *Ptr, long Purpose);
			void FixedPipeline(void *Ptr, long Purpose);
		}
	}
}

#endif