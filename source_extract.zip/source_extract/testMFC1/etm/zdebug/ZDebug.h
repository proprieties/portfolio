#ifndef __ZDEBUG_H
#define __ZDEBUG_H

#include <windows.h>
#include <stdlib.h>
#include <assert.h>
#include <windowsx.h>


inline void ErrorNotice(char* msg) {
	MessageBox(NULL, msg, "Error", MB_OK | MB_ICONERROR);
}
inline void ErrorAbort(char* msg) {
	ErrorNotice(msg);
	assert(FALSE);
}

#ifdef _DEBUG


#define CHECKERROR(data, msg)			if(!(data)) ErrorAbort(msg)
#define CHECKERRORFUNC(func, msg)		if(!(func)) ErrorAbort(msg)

#define ZASSERT(data, msg)				if(data) ErrorAbort(msg)

#define ZNOTICE(data, msg)				if(data) ErrorNotice(msg)

void __cdecl ZDebugBox(char* fmt, ...);
void __cdecl ZDebugFile(char* fmt, ...);

class CDebugWnd
{
	BOOL m_bOpenFlag;

	HWND m_hWnd;
	HINSTANCE m_hInst;

	HWND m_EditList;
	HWND m_EditListFixed;
public:
	CDebugWnd() {
		m_bOpenFlag = FALSE;
		m_hInst = NULL;
	};
	~CDebugWnd() {};

	void SetInstance(HINSTANCE hInst) {
		m_hInst = hInst;
	}
	HWND GetHWnd() {
		return m_hWnd;
	}

	BOOL OpenWindow();
	void OnPaint();

	void AddString(char* msg) {
		int count = ListBox_GetCount(m_EditList);
		if(count > 1000) {
			ListBox_DeleteString(m_EditList, 0);
		}

		ListBox_AddString(m_EditList, msg);
	}
	void AddStringFixed(int line, char* msg) {		
		int count = ListBox_GetCount(m_EditListFixed);
		if(count > line) {
			ListBox_InsertString(m_EditListFixed, line, msg);
			ListBox_DeleteString(m_EditListFixed, line + 1);
		} else {
			ListBox_AddString(m_EditListFixed, msg);
		}
	}
protected:
	BOOL Register();
	BOOL Create();
};

extern CDebugWnd DebugWnd;

inline void DEBUGWNDINIT(HINSTANCE hInst) {
	DebugWnd.SetInstance(hInst);

	HWND hWnd = GetFocus();
	DebugWnd.OpenWindow();
	SetFocus(hWnd);
}

void __cdecl ZDEBUGWND(char* fmt, ...);
void __cdecl ZDEBUGWNDFIXED(int line, char* fmt, ...);


#else	// NDEBUG


#define CHECKERROR(data, msg)			(0)
#define CHECKERRORFUNC(func, msg)		(func)

#define ZASSERT(data, msg)				(0)

#define ZNOTICE(data, msg)				(0)

inline void __cdecl ZDebugBox(char* fmt, ...) {}
inline void __cdecl ZDebugFile(char* fmt, ...) {}

#define DEBUGWNDINIT(hInst)				(0)

inline void __cdecl ZDEBUGWND(char* fmt, ...) {}
inline void __cdecl ZDEBUGWNDFIXED(int line, char* fmt, ...) {}

#endif	// _DEBUG

void __cdecl ZAssertBox(char* fmt, ...);

#endif