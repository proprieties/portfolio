#pragma once
#include "afxwin.h"
#include "afxcmn.h"

// CDlgTerrain ��ȭ �����Դϴ�.

class CDlgTerrain : public CDialog
{
	DECLARE_DYNAMIC(CDlgTerrain)

public:
	CDlgTerrain(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgTerrain();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_TERRAIN };
	enum { TERRAIN_TYPE_UP, TERRAIN_TYPE_DOWN,TERRAIN_TYPE_FLAT,TERRAIN_TYPE_ORIGIN };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
private:
//	My_Ogre*		m_OgreManager;

public:
	CSliderCtrl m_ctrlHeightSize;
	CSliderCtrl m_ctrlSliderStrong;

	int m_nHeightSize_static;
	int m_nUpDown;
	int m_nStrong;

public:
	void	Update();

	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	afx_msg void OnBnClickedUp();
	afx_msg void OnBnClickedFlat();
	afx_msg void OnNMCustomdrawSliderHsize(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderStrong(NMHDR *pNMHDR, LRESULT *pResult);
};
