// MainFrm.h : CMainFrame Ŭ������ �������̽�
//

#include "../controlj/TabBar.h"

#include "../controlj/DialogBase.h"
#include "../controlj/DialogCamera.h"
#include "../controlj/DialogOctree.h"
#include "../controlj/DialogRender.h"
#include "../controlj/DialogWindow.h"
#include "../controlj/DialogJeong.h"
#include "../controlj/DialogResource.h"

#include "ConsoleDoc.h"
#include "ConsoleView.h"

#pragma once

class CMainFrame : public CFrameWnd, public scene
{
protected: // serialization������ ��������ϴ�.
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Ư��
protected:
	CSplitterWnd SplitterMain, SplitterLeft, SplitterRight;
public:

// �۾�
public:
	void OnViewChangeMode();

// ������
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// ����
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // ��Ʈ�� ������ ���Ե� ����Դϴ�.
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// �޽��� �� �Լ��� �����߽��ϴ�.
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID);
	DECLARE_MESSAGE_MAP()

// ---------------------------------------------------------------------------

public: // scene
	HRESULT update(void);
	HRESULT resetdevice(jdevice::graphic *pGraphic);
	HRESULT lostdevice(void);

	CTabBar m_TabBar[2];
	CDialogBar m_BottomBar;
	
private: // interface of the other class
	CConsoleView *pRenderViewNow;

	class IRenderViewInterface : public CRenderView::CRenderViewInterface
	{
		CMainFrame *pMainFrame;
	public:
		IRenderViewInterface( CMainFrame *pMainFrame )
		{
			this->pMainFrame = pMainFrame;
		}
		void Select( CRenderView *pRenderView )
		{
			if(pRenderView)
			{
				pMainFrame->pRenderViewNow = (CConsoleView *)pRenderView;
				pMainFrame->m_DlgRender.ChangeWireFrameCheck(this->pMainFrame->pRenderViewNow->wireframe_state);
				pMainFrame->m_DlgRender.m_NumberSpin.SetPos(theApp.Frameworks.get_selected_form()->number);
				char cnumber[10];
				itoa(theApp.Frameworks.get_selected_form()->number, cnumber, sizeof(char) * 10);
				pMainFrame->m_DlgRender.m_NumberEdit.SetWindowText(cnumber);
			}
		}
	} m_RenderViewInterface;

	class CDialogExRender : public CDialogRender
	{
		CMainFrame *pMainFrame;
	public:
// - number(spin)
		void ChangeRenderView(int pos)
		{
			theApp.Frameworks.select_form(pos);
			pMainFrame->pRenderViewNow = (CConsoleView *)theApp.Frameworks.get_selected_form();
			if(pMainFrame->pRenderViewNow)
				pMainFrame->m_DlgRender.ChangeWireFrameCheck(this->pMainFrame->pRenderViewNow->wireframe_state);
		}
// - mode
		void ChangeMode()
		{
			theApp.Frameworks.changemodeform();
		}
// - camera
		void ChangeCamera(unsigned int number)
		{
//!			theApp.Frameworks.get_selected_form()->set_camera(theApp.Frameworks.resourcemgr.vcamera[number]);
		};
		void ChangeNode()
		{
/*!			node *pnode = (node *)pMainFrame->m_SceneTreeInterface.pPropertyTreeCtrl->GetItemData(
				pMainFrame->m_SceneTreeInterface.pPropertyTreeCtrl->GetSelectedItem());
			theApp.Frameworks.get_selected_form()->set_camera((camera *)pnode->resource);
*/		}
// - polygon
		void SetMainFrame(CMainFrame *pMainFrame)
		{
			this->pMainFrame = pMainFrame;
		}
		void ChangeWireFrame()
		{
			if(pMainFrame->pRenderViewNow)
				pMainFrame->pRenderViewNow->wireframe_state = !pMainFrame->pRenderViewNow->wireframe_state;
		}
	} m_DlgRender;

	class CDialogExScene : public CDialogBase
	{
		CTabBar *pTabBar; scene::node *node_now; CDialog *pDialog;
	public:
		void ChangeItem( TVITEM SelectedItem )
		{
//!			if(SelectedItem.lParam)
//!				pTabBar->ChangeDialog( (CDialog *)SelectedItem.lParam );
			pTabBar->ChangeDialog( (CDialog *)pDialog );
			node_now = (node *)SelectedItem.lParam;
		}
		HTREEITEM AddTree( char *strItemName, HTREEITEM hParentItem, void *pDialog )
		{
			HTREEITEM hItem = this->PropertyTree.InsertItem(TVIF_TEXT,
				_T(strItemName), 0, 0, 0, 0, (LPARAM)&this->PropertyTree, hParentItem, NULL);
			this->PropertyTree.SetItemData(hItem, (LPARAM)pDialog);
			return hItem;
		};
		void AddTree()
		{
			node *child = theApp.Frameworks.vscene[0]->add_node(node_now);

			HTREEITEM hItem = this->PropertyTree.InsertItem(TVIF_TEXT,
				_T("node"), 0, 0, 0, 0, (LPARAM)&this->PropertyTree, this->PropertyTree.GetSelectedItem(), NULL);
			this->PropertyTree.SetItemData(hItem, (LPARAM)child);
		};
		virtual void DeleteTree()
		{
			theApp.Frameworks.vscene[0]->delete_node((scene::node *)this->PropertyTree.GetItemData(this->PropertyTree.GetSelectedItem()));
			this->PropertyTree.DeleteItem( this->PropertyTree.GetSelectedItem() );
		};
		void SetDialog( CDialog *pDialog )
		{
			this->pDialog = pDialog;
		}
		void SetTreeInterface( CTabBar *pTabBar, CDialog *pDialog )
		{
			this->pDialog = pDialog;
			this->pTabBar = pTabBar;
		}
	} m_DlgScene;

	class CDialogExResource : public CDialogBase
	{
		CTabBar *pTabBar;
	public:
		void ChangeItem( TVITEM SelectedItem )
		{
			if(SelectedItem.lParam)
				pTabBar->ChangeDialog( (CDialog *)SelectedItem.lParam );
		}
		HTREEITEM AddTree( char *strItemName, HTREEITEM hParentItem, void *pDialog )
		{
			HTREEITEM hItem = this->PropertyTree.InsertItem(TVIF_TEXT,
				_T(strItemName), 0, 0, 0, 0, (LPARAM)&(this->PropertyTree), hParentItem, NULL);
			this->PropertyTree.SetItemData(hItem, (LPARAM)pDialog);
			return hItem;
		}
		void SetTreeInterface( CTabBar *pTabBar )
		{
			this->pTabBar = pTabBar;
		}
	} m_DlgResource;

	CDialog m_Dlg;
	CDialogCamera m_DlgCamera;
	CDialogOctree m_DlgOctree;
	CDialogWindow m_DlgWindow;
	CDialogJeong m_DlgJeong;

	class CDialogResourceMesh : public CDialogResource
	{
		resources::manager *presource;
		CDialogExScene *pscenetree;
	public:
		node* AddResource()
		{
			CFileDialog dialog(true);
			dialog.DoModal();
			int index = m_List.AddString( dialog.GetFileTitle() );
			model *pmodel = (model *)presource->add_resource(new model(D3DXVECTOR3(0, 0, 0)));
			pmodel->LoadMesh(dialog.GetPathName().GetBuffer(), &theApp.Frameworks.graphic);
//			theApp.m_mesh.LoadMesh(dialog.GetPathName().GetBuffer(), &theApp.Frameworks.graphic);
			m_List.SetItemData( index, (LPARAM)pmodel );
			return NULL;
		}
		CDialogResourceMesh( resources::manager *presource, CDialogExScene *pscenetree )
		{
			this->pscenetree = pscenetree;
			this->presource = presource;
		}
		void ChangeItem()
		{
			node *pnode = (node *)pscenetree->PropertyTree.GetItemData(pscenetree->PropertyTree.GetSelectedItem());
			int a=m_List.GetTextLen(m_List.GetCurSel());
			char str[100], str2[100];
			m_List.GetText(m_List.GetCurSel(), str2);
			sprintf(str, "model(%s)", str2);
			pscenetree->PropertyTree.SetItemText(pscenetree->PropertyTree.GetSelectedItem(), str);
			pnode->resource = (jdevice::graphic::data *)m_List.GetItemData(m_List.GetCurSel());
		}
	} m_DlgResMesh;

	class CDialogResourceHeightMap : public CDialogResource
	{
		resources::manager *presource;
		CDialogExScene *pscenetree;
	public:
		node* AddResource()
		{
			CFileDialog dialog(true);
			dialog.DoModal();
			int index = m_List.AddString( dialog.GetFileTitle() );
			jgeometry::resources::heightmap *heightmesh = (jgeometry::resources::heightmap *)presource->add_resource(new jgeometry::resources::heightmap());
			heightmesh->load(dialog.GetPathName().GetBuffer(), theApp.Frameworks.graphic.device);
			m_List.SetItemData( index, (LPARAM)heightmesh );
			return NULL;
		}
		CDialogResourceHeightMap( resources::manager *presource, CDialogExScene *pscenetree )
		{
			this->pscenetree = pscenetree;
			this->presource = presource;
		}
		void ChangeItem()
		{
			node *pnode = (node *)pscenetree->PropertyTree.GetItemData(pscenetree->PropertyTree.GetSelectedItem());
			int a=m_List.GetTextLen(m_List.GetCurSel());
			char str[100], str2[100];
			m_List.GetText(m_List.GetCurSel(), str2);
			sprintf(str, "model(%s)", str2);
			pscenetree->PropertyTree.SetItemText(pscenetree->PropertyTree.GetSelectedItem(), str);
			pnode->resource = (jdevice::graphic::data *)m_List.GetItemData(m_List.GetCurSel());
		}
	} m_DlgResHeightMap;

	class CDialogResourceCamera : public CDialogResource
	{
		resources::manager *presource;
		CDialogExScene *pscenetree;
	public:
		scene::node* AddResource()
		{
			node *pnode = (node *)presource->add_resource(new jgeometry::resources::camera());
			presource->add_resource(new jgeometry::resources::light());
//!			m_List.SetItemData( index, (LPARAM)pnode );
			return pnode;
		}
		CDialogResourceCamera( resources::manager *presource, CDialogExScene *pscenetree )
		{
			this->pscenetree = pscenetree;
			this->presource = presource;
		}
		void ChangeItem()
		{
			node *pnode = (node *)pscenetree->PropertyTree.GetItemData(pscenetree->PropertyTree.GetSelectedItem());
			pscenetree->PropertyTree.SetItemText(pscenetree->PropertyTree.GetSelectedItem(), "camera");
			pnode->resource = (jdevice::graphic::data *)m_List.GetItemData(m_List.GetCurSel());
		}
	} m_DlgResCamera;
public:
	afx_msg void OnClose();
	afx_msg void OnSize(UINT nType, int cx, int cy);
};
