#ifndef _SAMPLE_ENGINE_H_
#define _SAMPLE_ENGINE_H_

#include "Core_Graphics.h"
using namespace core::graphics;

#include "Core_Input.h"
using namespace core::input;

#include "Core_System.h"
using namespace core::system;

namespace sample {
	namespace engine {
		void Coordinate(void *Ptr, long Purpose);
		void Frustum(void *Ptr, long Purpose);
		void Objects(void *Ptr, long Purpose);
		void Heightmap(void *Ptr, long Purpose);
	}
}

#endif