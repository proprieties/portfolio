#ifndef __testOgreETM_h_
#define __testOgreETM_h_

#include "../baseApp/BaseApplication.h"
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
#include "../res/resource.h"
#endif

#include <CEGUI/CEGUI.h>
#include <CEGUI/CEGUISystem.h>
#include <CEGUI/CEGUISchemeManager.h>
#include <OgreCEGUIRenderer.h>

#include "ETTerrainManager.h"
#include "ETTerrainInfo.h"
#include "ETBrush.h"
#include "ETSplattingManager.h"

using namespace std;
using Ogre::uint;

#include <vector>

class testOgreETM : public BaseApplication
{
	vector<Vector3> object_list;
	bool firstframe;

	CEGUI::MouseButton convertOISMouseButtonToCegui(int buttonID)
	{
		switch (buttonID)
		{
		case 0: return CEGUI::LeftButton;
		case 1: return CEGUI::RightButton;
		case 2:	return CEGUI::MiddleButton;
		case 3: return CEGUI::X1Button;
		default: return CEGUI::LeftButton;
		}
	}

public:
	testOgreETM(void);
	virtual ~testOgreETM(void);

	// common

	// etm
private:
	ET::TerrainManager* mTerrainMgr;
	ET::SplattingManager* mSplatMgr;

protected:
	//	CEGUI::Renderer *mGUIRenderer;     // cegui renderer
	CEGUI::OgreCEGUIRenderer *mGUIRenderer;

	// app

protected:
	CEGUI::System *mGUISystem;         // cegui system
	RaySceneQuery* raySceneQuery;

protected:
	virtual void chooseSceneManager(void);
	virtual void createViewports(void);
	virtual void createCamera(void);
	virtual void createFrameListener();
	virtual void createScene(void);
//	bool handleQuit(const CEGUI::EventArgs& e);

	// listener
private:
	bool key_state_map;

	// etm
protected:
	RaySceneQuery *mRaySceneQueryET;     // The ray scene query pointer
	bool mLMouseDownET, mRMouseDownET;     // True if the mouse buttons are down
	bool mMMouseDownET;
//	SceneManager *mSceneMgr;           // A pointer to the scene manager
	SceneNode *mPointer;               // Our "pointer" on the terrain
	ET::Brush mEditBrush;              // Brush for terrain editing
	bool mDeform;                      // stores which mode we are in (deform or paint)
	uint mChosenTexture;                // which of the four splatting textures is to be used?

	// movement
	Vector3 mDirectionET;
	bool mMove;

	SceneNode* mCamNode;

	bool mContinue;

	RaySceneQuery *mRaySceneQueryETM;

	const ET::TerrainInfo* mTerrainInfo;

protected:
	void createEditBrush();
	void saveTerrain();
	void loadTerrain();
	void updateLightmap();

	// testOgre
private:
	AnimationState *ani;

	std::deque<Vector3> mWalkList;
	float mWalkSpeed, mDistance;
	Vector3 mDestination, mDirection;

 	RaySceneQuery *mRaySceneQuery;
 	Ray mouseRay;
 	SceneNode *mCurrentObject;
	int mCount;
	bool mLMouseDown, mRMouseDown;
	bool mMMouseDown;

public:
	void moveCamera();

//	bool frameRenderingQueued(const FrameEvent& evt);
	bool frameStarted(const FrameEvent& evt);
	bool frameEnded(const FrameEvent& evt);
//	void requestShutdown(void);

	bool processUnbufferedKeyInput(const FrameEvent& evt);
	virtual bool mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id );
	virtual bool mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id );
	virtual bool mouseMoved( const OIS::MouseEvent &arg );
	virtual bool keyPressed(const OIS::KeyEvent& arg);
	virtual bool keyReleased(const OIS::KeyEvent& arg);
};

#endif
