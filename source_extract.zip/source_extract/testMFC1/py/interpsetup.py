import sys, traceback, console
		
class stdfile:
    def __init__(self, file):
        self.buf = ''
        self.file = file
    def write(self, str):
		#self.file.write(`len(str)`)
		#self.file.write(str)
		#self.file.flush()
		console.write(str)
		
def runcode(cmd):
	try:
		try:
			print eval(cmd)
		except SyntaxError:
			exec cmd	
	except:
		print traceback.format_exc()
		

try:
	sys.ps1
except AttributeError:
	sys.ps1 = '>>> '
	sys.ps2 = '... '    

stdout = stdfile(sys.stdout)
stderr = stdfile(sys.stderr)
sys.stdout = stdout
sys.stderr = stderr
		
print sys.version
		
if __name__ == '__main__':
	while (1):
		try:
			print sys.ps1,
			cmd = sys.stdin.readline()
			if len(cmd) > 1:
				runcode(cmd)
		except (KeyboardInterrupt, SystemExit):
			break