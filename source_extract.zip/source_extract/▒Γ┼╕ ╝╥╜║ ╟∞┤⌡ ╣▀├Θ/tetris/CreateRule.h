#ifndef __CreateRule_H__
#define __CreateRule_H__

#include "CreateMap.h"
#include "CreateToyGroup.h"

enum CreateOrder
{
	NotOrder, LeftOrder, RightOrder, UpOrder, DownOrder, SpeedUpOrder, SpeedRestoreOrder, ExitOrder
};

class CreateRule
{
public:
	CreateMap Map;
	CreateToyGroup ToyGroup;

private:
	CreateOrder NowOrder;
	bool SpeedUpOrderDownUp;

public:
	void SetOrder(CreateOrder NewOrder);
	CreateRule();
	~CreateRule();
	bool Running();
};

#endif // __CreateRule_H__
