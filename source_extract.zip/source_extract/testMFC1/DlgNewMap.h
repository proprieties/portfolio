#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// DlgNewMap ��ȭ �����Դϴ�.

class DlgNewMap : public CDialog
{
	DECLARE_DYNAMIC(DlgNewMap)

public:
	DlgNewMap(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.

	virtual ~DlgNewMap();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_NEWMAP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnNMCustomdrawSliderCellspace(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderHeight(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLbnSelchangeListSize();
	afx_msg void OnBnClickedBtnSubmit();

	void		DrawTexture();

private:
	My_Ogre*		m_OgreManager;

public:
	CListBox m_ctrlMapSizeList;
	CListBox m_ctrlTextureList;
	CSliderCtrl m_ctrlHeight;
	CComboBox m_ctrlVertexNums;
	CStringList* m_pTextureList;
	CEdit m_ctrlMapName;

	CString		m_strName;
	int			m_nMapSize;
	int			m_nHeight;
	int			m_nTextureNum;

	int			m_nHeightStatic;
	int			m_nMapSizeStatic;
	int			m_nTextureNumStatic;

	afx_msg void OnCbnSelchangeCancel();
	afx_msg void OnCbnSelchangeVertexnum();
	afx_msg void OnLbnSelchangeListTexture();
	afx_msg void OnBnClickedBtnCancel();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnPaint();
	afx_msg void OnEnChangeName();
	afx_msg void OnEnUpdateName();
public:
	int		GetMapSize() const { return m_nMapSize; }
	int		GetHeightSize() const { return m_nHeight; }
	int		GetTextureNum() const { return m_nTextureNum; }
	CString GetMapName() const { return m_strName; }

};
