#ifndef _CORE_
#define _CORE_

// #include "../../../../../core/directx/DirectX 9 Aug2007/Include/d3d9.h"
// #include "../../../../../core/directx/DirectX 9 Aug2007/Include/d3dx9.h"

#include "stdio.h"

#include "jdevice.h"

namespace jcore
{
	using namespace jdevice;

	class fps
	{
	public:
		float		updatecount;
		double		lastupdatetime;
		jdevice::timer		*timer;
		float		fps_count;
		double		elapsedtime;

	public:
		bool get_interval( void );
		void update( void );
		fps(jdevice::timer *nowtimer);
		float get_fps( void );
	};
}

#endif /* _CORE_ */