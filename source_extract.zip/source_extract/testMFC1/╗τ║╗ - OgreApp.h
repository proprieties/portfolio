// mfc01.h : main header file for the mfc01 application
//
#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


// COgreApp:
// See mfc01.cpp for the implementation of this class
//

#include "etsample.cpp"

class COgreApp : public CWinApp
{
public:
	DemoETSM app;

	COgreApp();
	Ogre::Root *GetRoot() { return m_pRoot; }

// Overrides
public:
	virtual BOOL InitInstance();


	DECLARE_MESSAGE_MAP()

public:
	virtual void loadResources(void);
protected:
	virtual void setupResources(void);
	virtual bool autoConfigure(int width=800,int height=600, int bpp=32);
	virtual bool setup(void);
	void setConfigFile(const char *plugin, const char *config, const char *log, const char *res);
	virtual bool configure(void);
	virtual void createResourceListener(void);

#if 0
	virtual void chooseSceneManager(void);
	virtual void createViewports(void);
	virtual void createCamera(void);
	virtual void createFrameListener(void);
	virtual void createScene(void) = 0;    // pure virtual - this has to be overridden
	virtual void destroyScene(void){}    // Optional to override this
#endif


protected:
	bool InitOgre(void);

	Ogre::Root *m_pRoot;
	Ogre::Camera *m_pCamera;
	Ogre::SceneManager *m_pSceneMgr;
//	Ogre::ExampleFrameListener *m_pFrameListener;
	Ogre::RenderWindow *m_pWindow;

	Ogre::String m_strPluginFile, m_strConfigFile, m_strLogFile;
	Ogre::String m_strResourceFile;
	//String m_strWindowTitle;
public:
	virtual int ExitInstance();
};

