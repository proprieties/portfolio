#ifndef _SAMPLE_SYSTEM_H_
#define _SAMPLE_SYSTEM_H_

#include "Core_Graphics.h"
using namespace core::graphics;

#include "Core_Input.h"
using namespace core::input;

#include "Core_System.h"
using namespace core::system;

namespace sample {
	namespace system {
		void Timers(void *Ptr, long Purpose);
		void ThreadSemaphore(void *Ptr, long Purpose);
		void PopupMove(void *Ptr, long Purpose);
		void DataPackage(void *Ptr, long Purpose);
	}
}

#endif