#ifndef __CreateMap_H__
#define __CreateMap_H__

#include "CreatePoint.h"

class CreateToyGroup;

class CreateMap  
{
private:
	CreateToyGroup *ToyGroup;

	CreatePoint Size;
	bool SetSizeFlag;
	bool **Block;
//	bool Block[16][21];

	struct CreateNextMap
	{
		CreatePoint Size;
		CreatePoint Pos;
	}NextMap;

public:
	CreatePoint GetNextSize();
	CreatePoint GetNextPos();
	CreatePoint GetNextCenter();
	void Initialize(CreateToyGroup *NewToyGroup);
	void SetSize(int NewX, int NewY);
	CreatePoint GetSize();
	void AdjustMap();
	CreateMap();
	~CreateMap();
	bool IsBlock(int NewX, int NewY);
	void SetBlock(int NewX, int NewY, bool Data);
	void DeleteLine();
};

#endif // __CreateMap_H__
