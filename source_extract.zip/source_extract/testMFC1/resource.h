//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mfc01.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_CONTROLDLG                  103
#define IDD_DIA_CONTROL                 103
#define IDD_DLG_TERRAIN                 104
#define IDR_MAINFRAME                   128
#define IDR_mfc01TYPE                   129
#define IDD_DLG_OBJECT                  132
#define IDR_PY1                         134
#define IDC_TREE1                       1000
#define IDC_TAB_TERRAIN                 1001
#define IDC_TAB_MAPCTRL                 1001
#define IDC_SLIDER_HSIZE                1004
#define IDC_STATIC_HSIZE                1005
#define IDC_STATIC_STRONG               1006
#define IDC_SLIDER_STRONG               1007
#define IDC_UP                          1022
#define IDC_FLAT                        1024
#define IDC_SLIDER_BRUSHSIZE            1026
#define IDC_STATIC_BRUSHSIZE            1027
#define IDC_SLIDER_BRUSHINTEN           1028
#define IDC_STATIC_BRUSHINTEN           1029
#define IDC_SLIDER_SCALE_X              1046
#define IDC_EDIT_SCALE_X                1047
#define IDC_MESHLIST                    1048
#define IDC_EDIT_SCALE_Y                1049
#define IDC_EDIT_SCALE_Z                1050
#define IDC_EDIT_MOVE_Y                 1051
#define IDC_EDIT_MOVE_X                 1052
#define IDC_EDIT_MOVE_Z                 1053
#define IDC_EDIT_ROTATE_X               1055
#define IDC_EDIT_ROTATE_Y               1056
#define IDC_EDIT_ROTATE_Z               1058
#define IDC_CHK_SCALE_X                 1060
#define IDC_CHK_SCALE_Y                 1061
#define IDC_CHK_SCALE_Z                 1062
#define IDC_CHK_ROTATE_X                1063
#define IDC_CHK_ROTATE_Y                1064
#define IDC_CHK_ROTATE_Z                1065
#define IDC_SLIDER_SCALE_Y              1066
#define IDC_SLIDER_SCALE_Z              1067
#define IDC_CHK_SCALE_ALL               1068
#define IDC_SLIDER_ROTATE_X             1069
#define IDC_SLIDER_ROTATE_Y             1070
#define IDC_SLIDER_ROTATE_Z             1071
#define IDC_CHK_ROTATE_ALL              1072
#define IDC_SLIDER_MOVE_Y               1073
#define IDC_SLIDER_MOVE_X               1074
#define IDC_SLIDER_MOVE_Z               1075
#define IDC_CHK_MOVE_ALL                1076
#define IDC_CHK_MOVE_X                  1077
#define IDC_CHK_MOVE_Y                  1078
#define IDC_CHK_MOVE_Z                  1079
#define IDC_CHK_UNIT                    1080
#define IDC_CHK_OBJ                     1081

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
