#pragma once


// CHKRichEditView ���Դϴ�.

class CHKRichEditView : public CRichEditView
{
	DECLARE_DYNCREATE(CHKRichEditView)

protected:
	CHKRichEditView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CHKRichEditView();

public:
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	void WriteLine(CString str, COLORREF color=0);
	CString GetLine(int nLine);

protected:
	DECLARE_MESSAGE_MAP()
};


