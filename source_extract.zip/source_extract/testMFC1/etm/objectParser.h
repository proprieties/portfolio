/*---------------------------------------------------------------

objectParser

author		: jeong kim

date		: 2011. 02. 10. 13:56

description	: The position of objects in terrain editor.

---------------------------------------------------------------*/

#ifndef __objectParser_h_
#define __objectParser_h_

#define TERRAIN

#if defined(TERRAIN)
#include <ogreVector3.h>
using namespace Ogre;
#elif defined(SERVER)
struct Vector3
{
	float x, y, z;
};
#endif

#include <vector>
#include <fstream>

using namespace std;

typedef struct world_type {
	int size_x, size_y, height_max;
} worldT;

typedef struct object_type {
	string meshname;
	Vector3 position;
	Quaternion rotation;
	Vector3 scale;
} objectT;

class objectParser
{
	worldT &world;
	vector<objectT> &object_list;

public:
	objectParser(worldT& worldn, vector<objectT>& objects);
	int save(string filename);
	int load(string filename);
};

#endif