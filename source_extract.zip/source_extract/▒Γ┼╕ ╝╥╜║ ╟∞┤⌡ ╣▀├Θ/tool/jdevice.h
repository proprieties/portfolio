#ifndef _DEVICE_
#define _DEVICE_

#pragma once

#include "../../../../../core/directx/DirectX 9 Aug2007/Include/d3d9.h"
#include "../../../../../core/directx/DirectX 9 Aug2007/Include/d3dx9.h"
//#include "../../../../../core/directx/jimAdams/D3D8or9.h"

namespace jdevice
{
	class graphic
	{
	public:
		LPDIRECT3D9       direct3d;
		LPDIRECT3DDEVICE9 device;
		bool initialized;
		D3DPRESENT_PARAMETERS ppwin, ppfull;
	public:
		graphic(void) {};
		~graphic(void) {};
	public:
		class data
		{
		public:
			virtual void lost() = 0;
			virtual void reset( jdevice::graphic *graphic ) = 0;
			virtual void render( jdevice::graphic *graphic ) = 0;
			virtual void update(){};
			data() {};
			virtual ~data() {};
		};
		virtual void initialize( HWND MainWindow, HWND FullWindow, bool full_screen ) throw(char *)
		{
			this->direct3d = Direct3DCreate9( D3D_SDK_VERSION );
			if( this->direct3d == NULL )
				throw "failed initialize direct3d";
		D3DDISPLAYMODE d3ddm_max, d3ddm_temp;
		memset(&d3ddm_max, 0, sizeof(d3ddm_max));
		bool found_mode = false;

		int adaptormodes_count = this->direct3d->GetAdapterModeCount( D3DADAPTER_DEFAULT, D3DFMT_X8R8G8B8 );
		
		for( int number = 0; number < adaptormodes_count; ++number )
		{
			if( FAILED( this->direct3d->EnumAdapterModes( D3DADAPTER_DEFAULT, D3DFMT_X8R8G8B8, number, &d3ddm_temp ) ) )
				throw "failed enumerate adaptor modes";

			if( d3ddm_max.Width < d3ddm_temp.Width && d3ddm_max.Height < d3ddm_temp.Height )
			if( d3ddm_temp.Format == D3DFMT_X8R8G8B8 )
			if( d3ddm_temp.RefreshRate == 60 )
			{
				d3ddm_max = d3ddm_temp;
				found_mode = true;
			}
		}

		if( found_mode == false )
			throw "failed enumerate adaptor modes";

		//
		// Verify hardware support...

		// Can we get a 32-bit back buffer?
		if( FAILED( this->direct3d->CheckDeviceType( D3DADAPTER_DEFAULT,
											D3DDEVTYPE_HAL,
											D3DFMT_X8R8G8B8,
											D3DFMT_X8R8G8B8,
											FALSE ) ) )
			throw "this device can't support 32-bit back buffer";

		HRESULT hr;

		if( FAILED( hr = this->direct3d->CheckDeviceFormat( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, 
													d3ddm_temp.Format, D3DUSAGE_DEPTHSTENCIL,
													D3DRTYPE_SURFACE, D3DFMT_D16 ) ) )
		{
			if( hr == D3DERR_NOTAVAILABLE )
				// POTENTIAL PROBLEM: We need at least a 16-bit z-buffer!
				throw "this device can't support 16-bit z-buffer";
		}

		D3DCAPS9 d3dCaps;

		if( FAILED( this->direct3d->GetDeviceCaps( D3DADAPTER_DEFAULT, 
										D3DDEVTYPE_HAL, &d3dCaps ) ) )
		{
			// TO DO: Respond to failure of GetDeviceCaps
			throw "failed get device caps";
		}

		DWORD dwBehaviorFlags = 0;

		if( d3dCaps.VertexProcessingCaps != 0 )
			dwBehaviorFlags |= D3DCREATE_HARDWARE_VERTEXPROCESSING;
		else
			dwBehaviorFlags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;

			memset(&this->ppwin, 0, sizeof(this->ppwin));

		this->ppwin.BackBufferFormat       = d3ddm_temp.Format;
		this->ppwin.SwapEffect             = D3DSWAPEFFECT_DISCARD;
		this->ppwin.Windowed               = TRUE;
		this->ppwin.EnableAutoDepthStencil = TRUE;
		this->ppwin.AutoDepthStencilFormat = D3DFMT_D16;
		this->ppwin.PresentationInterval   = D3DPRESENT_INTERVAL_IMMEDIATE;
		this->ppwin.hDeviceWindow			 = MainWindow;

			memset(&this->ppfull, 0, sizeof(this->ppfull));

		this->ppfull.EnableAutoDepthStencil = TRUE;
		this->ppfull.AutoDepthStencilFormat = D3DFMT_D16;
		this->ppfull.SwapEffect             = D3DSWAPEFFECT_DISCARD;
		this->ppfull.BackBufferWidth        = d3ddm_temp.Width;
		this->ppfull.BackBufferHeight       = d3ddm_temp.Height;
		this->ppfull.BackBufferFormat       = D3DFMT_X8R8G8B8;
		this->ppfull.PresentationInterval   = D3DPRESENT_INTERVAL_IMMEDIATE;
		this->ppfull.hDeviceWindow			 = FullWindow;

		if(!full_screen)
		{
			if( FAILED( this->direct3d->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, FullWindow,
				/* �ֽô��ʿ� �ֻ��� ������� FullWindow���� FullWindow���� alt+tab�� �ϰ� FullWindow�� ����(reset()) �� ��,
				TestCooperativeLevel���� D3DERR_DEVICENOTRESET�� return ���� �� �ִ�.
				�׷��� ������ TestCooperativeLevel���� FullWindow�� �����ص� lostdevice�� return�Ѵ�.
				*/
											dwBehaviorFlags, &this->ppwin, &this->device ) ) )
				throw "failed create device";
		}
		else
		{
			if( FAILED( this->direct3d->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, FullWindow,
											dwBehaviorFlags, &this->ppfull, &this->device ) ) )
				throw "failed create device";
		}

		this->initialized=true;
		}
		virtual void release()
		{
	if( this->device != NULL )
	{
        this->device->Release();
		this->device = NULL;
	}
    if( this->direct3d != NULL )
	{
		this->direct3d->Release();
		this->direct3d = NULL;
	}
		}
		virtual void lost() {};
		virtual void reset() {};
		virtual void render() {};
	};

	class timer
	{
		bool		bUsingQPF;
	    LONGLONG	llQPFTicksPerSec;
		LONGLONG	llBaseTime;
	    LONGLONG	llLastElapsedTime;

		float		fElapsedTime;

		float		speed;

	public:
		timer( void );
		float get_absolute_time( void );
		float update( void );
		float get_elapsed_time( void );
		void set_speed(float speed);
	};
}

#endif _DEVICE_