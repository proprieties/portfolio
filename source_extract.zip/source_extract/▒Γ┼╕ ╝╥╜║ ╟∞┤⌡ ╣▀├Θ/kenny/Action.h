#ifndef __Action_H__
#define __Action_H__

#include "PoseOff.h"

struct ActionData
{
	int NowPose;
	int PoseCount;
	LPDIRECTDRAWSURFACE7 *ppDDSPose;
};

class Action
{
public:
	Action(int NewPoseCount);
	~Action();

private:
	ActionData Data;

public:
	void Running();
	SetPose(LPDIRECTDRAWSURFACE7 *ppNewPose);//Pose type File
/* //-- S:Off Screen ����
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd); 
 	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
	ddsd.dwHeight = SizeX;
	ddsd.dwWidth = SizeY;

	pDD7->CreateSurface( &ddsd, &pDDSPose, NULL);
*/ //-- E:Off Screen ����
};

#endif// __Action_H__