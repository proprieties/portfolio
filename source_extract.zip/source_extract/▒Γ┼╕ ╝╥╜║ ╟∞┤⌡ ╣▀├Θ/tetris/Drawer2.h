#ifndef __Drawer3_H__
#define __Drawer3_H__

#include <windows.h>
#include <ddraw.h>
#include <ctime>
#include "CreatePoint.h"

class CreateMap;
class CreateToyGroup;

#include "Drawer.h"

class Drawer2 : public DrawerAb
{
private:
	CreateMap *Map;
	CreateToyGroup *ToyGroup;

	clock_t DrawStart;
	float DrawTime;

	CreatePoint BlockSize;

	HWND hwnd;
	HDC hdc;
	LPDIRECTDRAW7 pDDraw7;
	LPDIRECTDRAWSURFACE7 pSPri;

public:
	void ReDrawNextMap();
	void Drawing();
	bool Initialize(CreateMap *NewMap, CreateToyGroup *NewToyGroup, HWND hwndNew);
	void Destroy();
	Drawer2();
	~Drawer2();
	void DrawNowToySet();
	void DrawNextToySet();
	void ReDrawMap();
	void ErasePrevToySet();
	void DrawBlock(int X, int Y, COLORREF color);
	void DrawMap();
};

#endif // __Drawer2_H__
