#ifndef __Animation_H__
#define __Animation_H__

#include "Gapper.h"
using namespace GapCheck;
#include <ddraw.h>

struct AnimationData
{
	int Count;
	float Time;
	LPDIRECTDRAWSURFACE7 *apScene;
};

class Animation  
{
public:
	Animation();
	~Animation();

private:
	bool bAniStart;
	int AniCount;
	int SizeX, SizeY;
	int StaffSizeX, StaffSizeY;
	AnimationData *Data;
	int NowAni;
	int NowScene;
	bool bUsing;
	LPDIRECTDRAWSURFACE7 pDisplay;
	Gapper Gap;
	int NowPosX, NowPosY;

public:
	Gapper GapScene;
	bool CheckEndScene();
	void StartScene();
	bool CheckEndAni(float AniTime);
	void StartAni();
	float GetTimeScene();
	bool Running(int PosX, int PosY, int AniNum, float AniTime,
		int CltSizeX=0, int CltSizeY=0);
	void ClearDisplay(int PosX, int PosY);
	int GetNowScene();
	int GetNowAni();
	int GetAniCount();
	int GetSceneCount();
	void SetNowScene(int NewNowScene);
	void SetNowAni(int NewNowAni);
	void CloseAni();
	bool SetAniDef(LPDIRECTDRAW7 pDD, LPDIRECTDRAWSURFACE7 pDisplayer);
};

#endif// __Animation_H__
