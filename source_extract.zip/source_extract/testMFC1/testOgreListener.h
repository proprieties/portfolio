#pragma once

/*
//Use this define to signify OIS will be used as a DLL
//(so that dll import/export macros are in effect)
#define OIS_DYNAMIC_LIB
#include <OIS/OIS.h>

#include <CEGUI.h>
#include <CEGUISystem.h>
#include <CEGUISchemeManager.h>
#include <OgreCEGUIRenderer.h>
*/

#define OIS_DYNAMIC_LIB

#include "Ogre.h" 
#include "OgreFrameListener.h" 
#include <OIS/OIS.h>

#include <deque>
#include <strstream>

using namespace Ogre;

namespace myOgre
{
	namespace InputListners // non-use in MFC
	{
		class InputListner : public OIS::KeyListener, public OIS::MouseListener
		{
		public: 
			bool keyPressed(const OIS::KeyEvent& e){ return true; }
			bool keyReleased(const OIS::KeyEvent& e){ return true; }
		public: 
			bool mouseMoved(const OIS::MouseEvent& e){ return true; }
			bool mousePressed(const OIS::MouseEvent& e, OIS::MouseButtonID id){ return true; }
			bool mouseReleased(const OIS::MouseEvent& e, OIS::MouseButtonID id){ return true; }
		};

		class SimpleKeyListener : public OIS::KeyListener 
		{ 
		public: 
			bool keyPressed(const OIS::KeyEvent& e){ return true; }
			bool keyReleased(const OIS::KeyEvent& e){ return true; }
		};

		class SimpleMouseListener : public OIS::MouseListener
		{
		public: 
			bool mouseMoved(const OIS::MouseEvent& e){ return true; }
			bool mousePressed(const OIS::MouseEvent& e, OIS::MouseButtonID id){ return true; }
			bool mouseReleased(const OIS::MouseEvent& e, OIS::MouseButtonID id){ return true; }
		};
	}

	using namespace InputListners;

	class testOgreFrameListener;

	class testOgrePureFrameListener : public Ogre::FrameListener
	{
	public:
		struct sceneData
		{
			SceneManager* mSceneMgr;
			Ogre::RenderWindow *m_pWindow;
			Ogre::Camera *m_pCamera;

			RaySceneQuery* raySceneQuery;
			RaySceneQuery *mRaySceneQuery; // only
			SceneNode *mCurrentObject; //
			int mCount;

			AnimationState *ani; //
			std::deque<Vector3> mWalkList;
			float mWalkSpeed, mDistance;
			Vector3 mDestination, mDirection;

			Ogre::Vector3 mTranslateVector; //

			Ogre::Radian mRotX, mRotY;

			bool mLMouseDown, mRMouseDown;
			CPoint m_ptPos;
			MSG m_Msg;

			testOgreFrameListener *mListener;
		};
	private:
		sceneData *mScene;
	public:
		testOgrePureFrameListener(sceneData *scene)
		{
			mScene = scene;
		}
		// Ogre::FrameListener
		virtual	bool frameStarted(const Ogre::FrameEvent &evt);
		virtual	bool frameEnded(const Ogre::FrameEvent &evt);
	};

	class testOgreFrameListener// : public Ogre::FrameListener//, public OIS::KeyListener, public OIS::MouseListener
	{
		InputListner input;

	public:
		testOgreFrameListener();
		virtual ~testOgreFrameListener();

	public:
		testOgrePureFrameListener::sceneData mScene;

	// Operations
	public:
		//OIS Input devices
		OIS::InputManager* mInputManager;
		OIS::Mouse*    mMouse;
		OIS::Keyboard* mKeyboard;
		OIS::JoyStick* mJoy;

		HWND m_hWnd;

	//	CEGUI::Renderer* mGUIRenderer;
 		bool mShutdownRequested;
	//	bool mUseBufferedInputKeys, mUseBufferedInputMouse, mInputTypeSwitchingOn;

		Ogre::Root *m_pRoot;

		int mSceneDetailIndex ;
		Ogre::Real mMoveSpeed;
		Ogre::Degree mRotateSpeed;
		Ogre::Overlay* m_pDebugOverlay;

		bool mStatsOn;
		bool mUseBufferedInputKeys, mUseBufferedInputMouse, mInputTypeSwitchingOn;
		unsigned int mNumScreenShots;
		float mMoveScale;
		Ogre::Degree mRotScale;
		// just to stop toggles flipping too fast
		Ogre::Real mTimeUntilNextToggle ;
		Ogre::TextureFilterOptions mFiltering;
		int mAniso;

		// custumizing
		void renderwindow_resize(void);
		bool event_message(MSG* pMsg);

		// ExampleFrameListener
		void moveCamera();

		// ExampleApplication
		virtual void chooseSceneManager(void);
		virtual void createViewports(void);
		virtual void createCamera(void);
		virtual void createFrameListener(void);
		virtual void createScene(void);
		virtual void destroyScene(void);    // Optional to override this

		void UpdateStats(void);
		void ShowDebugOverlay(bool show);

		bool setup(HWND hWnd, CRect rect);
	};

	class testOgreApp
	{
	public:
		testOgreApp();
		~testOgreApp();
		Ogre::Root *GetRoot() { return m_pRoot; }

	public:
		virtual void loadResources(void);
	protected:
		virtual void setupResources(void);
		virtual bool autoConfigure(int width=800,int height=600, int bpp=32);
	public: //
		virtual bool setup(void);
	protected:
		void setConfigFile(const char *plugin, const char *config, const char *log, const char *res);
		virtual bool configure(void);
		virtual void createResourceListener(void);
	protected:
//		bool InitOgre(void);

	public: //
		Ogre::Root *m_pRoot;

		Ogre::String m_strPluginFile, m_strConfigFile, m_strLogFile;
		Ogre::String m_strResourceFile;
		//String m_strWindowTitle;
	};
}