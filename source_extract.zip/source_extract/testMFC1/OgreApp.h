// mfc01.h : main header file for the mfc01 application
//
#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


// COgreApp:
// See mfc01.cpp for the implementation of this class
//

#include "etsample.cpp"

#include "testOgreListener.h"
#include "testTerrainListener.h"

class COgreApp : public CWinApp
{
public:
	DemoETSM app;

	std::vector<unsigned int> commands;

//	myOgre::testOgreApp ogreApp;
	myOgre::testTerrainApp ogreApp;
	myOgre::testTerrainFrameListener listener;

	COgreApp();

// Overrides
public:
	virtual BOOL InitInstance();


	DECLARE_MESSAGE_MAP()

#if 0
	virtual void chooseSceneManager(void);
	virtual void createViewports(void);
	virtual void createCamera(void);
	virtual void createFrameListener(void);
	virtual void createScene(void) = 0;    // pure virtual - this has to be overridden
	virtual void destroyScene(void){}    // Optional to override this
#endif


public:
	virtual int ExitInstance();
};

