#pragma once

#include "resource.h"       // main symbols

#include "OgreApp.h"

// CMyApp

class CMyApp : public COgreApp
{
	DECLARE_DYNCREATE(CMyApp)

public:
	CMyApp();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CMyApp();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

	// Implementation
	afx_msg void OnAppAbout();

protected:
	DECLARE_MESSAGE_MAP()
};

extern CMyApp theApp;

