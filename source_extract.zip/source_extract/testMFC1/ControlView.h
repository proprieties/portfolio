#pragma once

//#include "OgreBase.h"
#include "DlgTerrain.h"
// #include "DlgTexture.h"
#include "DlgObject.h"
// #include "DlgParticle.h"
#include "afxcmn.h"
#include "afxwin.h"


// CControlView �� ���Դϴ�.

class CControlView : public CFormView
{
	DECLARE_DYNCREATE(CControlView)

public:
	CControlView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CControlView();

public:
	enum { IDD = IDD_DIA_CONTROL };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

private:
//	My_Ogre*		m_OgreManager;

public:
	virtual void OnInitialUpdate();
	afx_msg void OnTcnSelchangeTabMapctrl(NMHDR *pNMHDR, LRESULT *pResult);

	CTabCtrl			m_TabEditMenu;
	CDlgTerrain*		m_pDlgTerrain;
// 	CDlgTexture*		m_pDlgTexture;
 	CDlgObject*			m_pDlgObject;
// 	CDlgParticle*		m_pDlgParticle;

	CSliderCtrl m_ctrlBrushSize;
	int m_nBrushSize;
	int m_nOldBrushSize;
	CSliderCtrl m_ctrlSliderBrushStrong;
	int m_nBrushStrong;


	afx_msg void OnNMCustomdrawSliderBrushsize(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderBrushinten(NMHDR *pNMHDR, LRESULT *pResult);

protected:
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
public:
	afx_msg void OnPaint();

};


