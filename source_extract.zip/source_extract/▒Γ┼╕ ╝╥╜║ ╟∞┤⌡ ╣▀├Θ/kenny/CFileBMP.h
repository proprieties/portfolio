#ifndef __CFileBMP_H__
#define __CFileBMP_H__

#include <windows.h>

class CFileBMP
{
private:
	HANDLE hfBMP;
	DWORD dwBytes;

//!protected:
public:
	BITMAPFILEHEADER *pbmfh;
	BITMAPINFOHEADER *pbmih;
	RGBQUAD *pRGBTable;
	BYTE *pBits;
	int nSizeBit;
	int nSizeColorTable;

public://���� ���� ���
	bool err;

public:
	CFileBMP();
	~CFileBMP();
	bool OpenFile(char *szFileName);

public: //private variable�� ���� public method
	LONG GetWidth();
	LONG GetHeight();
	BYTE *GetBits();
	BITMAPINFOHEADER *GetBITMAPINFO();
	int GetSize();
	RGBQUAD *GetClrTable();
	int GetSizePal();
};

#endif// __CFileBMP_H__