#ifndef _SAMPLE_H_
#define _SAMPLE_H_

#include "Core_Graphics.h"
using namespace core::graphics;

#include "Core_Input.h"
using namespace core::input;

#include "Core_System.h"
using namespace core::system;

#include "../tools/tools2d/resource.h"

#include "./engine.h"
#include "./graphics.h"
#include "./math.h"
#include "./system.h"
#include "./language/language.h"

#include <stdlib.h>
#include <stdio.h>

namespace sample {
	class cApp : public cApplication
	{
		friend class graphics::Image::spriteInfo;
		friend class graphics::Image::spriteInfoMultiple;
		friend class graphics::Image::spriteInfoRegion;
		friend class graphics::Image::spriteInfoConstant;
		friend void graphics::Image::SpriteTool(void *Ptr, long Purpose);
		friend void graphics::Effects::Alpha(void *Ptr, long Purpose);
		friend void graphics::Font::Font(void *Ptr, long Purpose);
		friend void graphics::Font::Font2(void *Ptr, long Purpose);
		friend void graphics::Geometry::Line2D(void *Ptr, long Purpose);
		friend void graphics::Geometry::Line3D(void *Ptr, long Purpose);
		friend void graphics::Geometry::Draw2D(void *Ptr, long Purpose);
		friend void graphics::Geometry::Draw3D(void *Ptr, long Purpose);
		friend void graphics::Effects::Billboard(void *Ptr, long Purpose);
		friend void graphics::Effects::Lights(void *Ptr, long Purpose);
		friend void graphics::Device::ZBuffer(void *Ptr, long Purpose);
		friend void graphics::Effects::Particles(void *Ptr, long Purpose);
		friend void graphics::Transform::Transform2D(void *Ptr, long Purpose);
		friend void graphics::Transform::Transform(void *Ptr, long Purpose);
		friend void graphics::Transform::FixedPipeline(void *Ptr, long Purpose);
		friend void math::CircleCollision(void *Ptr, long Purpose);
		friend void math::Triangle(void *Ptr, long Purpose);
		friend void math::RotationByMouse(void *Ptr, long Purpose);
		friend void math::DotPlaneCollision(void *Ptr, long Purpose);
		friend void system::Timers(void *Ptr, long Purpose);
		friend void system::PopupMove(void *Ptr, long Purpose);
		friend void system::DataPackage(void *Ptr, long Purpose);
		friend void language::BitOperator(void *Ptr, long Purpose);
		friend void engine::Coordinate(void *Ptr, long Purpose);
		friend void engine::Frustum(void *Ptr, long Purpose);
		friend void engine::Objects(void *Ptr, long Purpose);
		friend void engine::Heightmap(void *Ptr, long Purpose);
		friend void system::ThreadSemaphore(void *Ptr, long Purpose);
		friend void math::MatrixVector(void *Ptr, long Purpose);

		POINT ps;

		virtual LRESULT FAR PASCAL MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
			switch(uMsg) {
			// WS_POPUP�� ��� �̵��� ���ؼ� ���ȴ�.
			case WM_LBUTTONDOWN:
				long x=LOWORD(lParam), y=HIWORD(lParam);
				ps.x = x; ps.y = y;
			}
			return DefWindowProc(hWnd, uMsg, wParam, lParam);
		}

	private:
		cGraphics       m_Graphics;

		cStateManager m_StateManager;
		void (*Process[29])(void *Ptr, long Purpose);

		unsigned int m_Number;

		cInput		m_Input;
		cInputDevice Keyboard;
		cInputDevice m_Mouse;

	public:
		cApp(unsigned int number);

		BOOL Init();
		BOOL Shutdown();
		BOOL Frame();
	};
}

#endif