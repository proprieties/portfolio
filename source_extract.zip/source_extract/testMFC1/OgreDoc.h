// OgreDoc.h : interface of the COgreDoc class
//


#pragma once

class COgreDoc : public CDocument
{
protected: // create from serialization only
	COgreDoc();
	DECLARE_DYNCREATE(COgreDoc)

// Attributes
public:

// Operations
public:

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~COgreDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};


