#pragma once


class OgreFrameListener : public ExampleFrameListener, public OIS::KeyListener, public OIS::MouseListener
{
private:
	SceneManager* mSceneMgr;
	CEGUI::Renderer* mGUIRenderer;
	bool mShutdownRequested;
	bool mUseBufferedInputKeys, mUseBufferedInputMouse, mInputTypeSwitchingOn;

public:
	OgreFrameListener(SceneManager *sceneMgr, RenderWindow* win, Camera* cam, CEGUI::Renderer* renderer);
	bool frameStarted(const FrameEvent& evt);
	void requestShutdown(void);
	void switchMouseMode();
	void switchKeyMode();
	bool frameEnded(const FrameEvent& evt);
	bool mouseMoved( const OIS::MouseEvent &arg );
	bool mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id );
	bool mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id );
	bool keyPressed( const OIS::KeyEvent &arg );
	bool keyReleased( const OIS::KeyEvent &arg );
	bool processUnbufferedKeyInput(const FrameEvent& evt);
	void moveCamera(void);
};