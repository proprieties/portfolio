#ifndef __ETM_H__
#define __ETM_H__

#include "../baseApp/BaseApplication.h"
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
#include "../res/resource.h"
#endif

#include <CEGUI/CEGUISystem.h>
#include <CEGUI/CEGUISchemeManager.h>
#include <OgreCEGUIRenderer.h>

#include "ETTerrainManager.h"
#include "ETTerrainInfo.h"
#include "ETBrush.h"
#include "ETSplattingManager.h"

using namespace std;
using Ogre::uint;

class etmApp : public BaseApplication
{
public:
	etmApp(void);
	virtual ~etmApp(void);

	// common

private:
	ET::TerrainManager* mTerrainMgr;
	ET::SplattingManager* mSplatMgr;

protected:
//	CEGUI::Renderer *mGUIRenderer;     // cegui renderer
	CEGUI::OgreCEGUIRenderer *mGUIRenderer;

	// app

protected:
	CEGUI::System *mGUISystem;         // cegui system

protected:
	virtual void chooseSceneManager(void);
	virtual void createScene(void);
	virtual void createFrameListener();

	// listener

protected:
	RaySceneQuery *mRaySceneQuery;     // The ray scene query pointer
	bool mLMouseDown, mRMouseDown;     // True if the mouse buttons are down
	bool mMMouseDown;
//	SceneManager *mSceneMgr;           // A pointer to the scene manager
	SceneNode *mPointer;               // Our "pointer" on the terrain
	ET::Brush mEditBrush;              // Brush for terrain editing
	bool mDeform;                      // stores which mode we are in (deform or paint)
	uint mChosenTexture;                // which of the four splatting textures is to be used?

	// movement
	Vector3 mDirection;
	bool mMove;

	SceneNode* mCamNode;

	bool mContinue;

	const ET::TerrainInfo* mTerrainInfo;

protected:
	 void createEditBrush();
	 bool frameStarted(const FrameEvent &evt);
	 virtual bool mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id );
	 virtual bool mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id );
	 virtual bool mouseMoved( const OIS::MouseEvent &arg );
	 virtual bool keyPressed(const OIS::KeyEvent& arg);
	 virtual bool keyReleased(const OIS::KeyEvent& arg);
	 void saveTerrain();
	 void loadTerrain();
	 void updateLightmap();
};

#endif
