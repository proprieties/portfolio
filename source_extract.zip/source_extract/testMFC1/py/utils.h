
#ifdef _DEBUG 
#undef _DEBUG 
#include <python.h>
#define _DEBUG 
#else 
#include <python.h>
#endif 

bool GetHTML(const int& idrHTML, CString& rString);
bool py_import(const char *src, char *filename);
