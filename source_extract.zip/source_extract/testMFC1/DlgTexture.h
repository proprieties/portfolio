#pragma once
#include "afxwin.h"


// CDlgTexture ��ȭ �����Դϴ�.

class CDlgTexture : public CDialog
{
	DECLARE_DYNAMIC(CDlgTexture)

public:
	CDlgTexture(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgTexture();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_TEXTURE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
private:
	My_Ogre*		m_OgreManager;

protected:
	CStringList*		m_pTextureList;
	CListBox			m_ctrlTextureList;


public:
	void				Update();
	void				DrawTexture();
	int					m_nTextureNum;

	afx_msg void OnLbnSelchangeTexturetabList();
	afx_msg void OnPaint();
};
