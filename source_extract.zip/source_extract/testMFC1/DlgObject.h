#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// CDlgObject ��ȭ �����Դϴ�.

class CDlgObject : public CDialog
{
	DECLARE_DYNAMIC(CDlgObject)

public:
	CDlgObject(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgObject();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DLG_OBJECT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	void	Init();
	void	Update();
	void	LoadMeshList();
	void	SaveOldScalaData();

	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	afx_msg void OnLbnSelchangeListObject();
	afx_msg void OnCbnSelchangeMeshlist();

private:
//	My_Ogre*		m_OgreManager;

public:
	BOOL m_ctrlCheckMoveAll;
	BOOL m_ctrlCheckMoveX;
	BOOL m_ctrlCheckMoveY;
	BOOL m_ctrlCheckMoveZ;

	BOOL m_ctrlCheckScaleAll;
	BOOL m_ctrlCheckScaleX;
	BOOL m_ctrlCheckScaleZ;
	BOOL m_ctrlCheckScaleY;

	BOOL m_ctrlCheckRotateAll;
	BOOL m_ctrlCheckRotateX;
	BOOL m_ctrlCheckRotateY;
	BOOL m_ctrlCheckRotateZ;

	BOOL m_ctrlCheckUnitList;
	BOOL m_ctrlCheckObjList;
	

	float m_fMoveX;
	float m_fMoveY;
	float m_fMoveZ;

	float m_fScaleX;
	float m_fScaleY;
	float m_fScaleZ;

	float m_fRotateX;
	float m_fRotateY;
	float m_fRotateZ;

	float m_OriMoveX;
	float m_OriMoveY;
	float m_OriMoveZ;

	float m_OriScaleX;
	float m_OriScaleY;
	float m_OriScaleZ;

	float m_OriRotateX;
	float m_OriRotateY;
	float m_OriRotateZ;

	CComboBox m_ctrlMeshList;

	CSliderCtrl m_ctrlSliderMoveX;
	CSliderCtrl m_ctrlSliderMoveY;
	CSliderCtrl m_ctrlSliderMoveZ;

	CSliderCtrl m_ctrlSliderScaleX;
	CSliderCtrl m_ctrlSliderScaleY;
	CSliderCtrl m_ctrlSliderScaleZ;

	CSliderCtrl m_ctrlSliderRotateX;
	CSliderCtrl m_ctrlSliderRotateY;
	CSliderCtrl m_ctrlSliderRotateZ;


	afx_msg void OnEnKillfocusEditScaleX();
	afx_msg void OnEnKillfocusEditScaleY();
	afx_msg void OnEnKillfocusEditScaleZ();

	afx_msg void OnNMCustomdrawSliderMoveY(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderMoveX(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderMoveZ(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnNMCustomdrawSliderScaleX(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderScaleY(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderScaleZ(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnNMCustomdrawSliderRotateX(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderRotateY(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderRotateZ(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnBnClickedChkMoveAll();
	afx_msg void OnBnClickedChkMoveX();
	afx_msg void OnBnClickedChkMoveY();
	afx_msg void OnBnClickedChkMoveZ();

	afx_msg void OnBnClickedChkScaleAll();
	afx_msg void OnBnClickedChkScaleX();
	afx_msg void OnBnClickedChkScaleY();
	afx_msg void OnBnClickedChkScaleZ();

	afx_msg void OnBnClickedChkRotateAll();
	afx_msg void OnBnClickedChkRotateX();
	afx_msg void OnBnClickedChkRotateY();
	afx_msg void OnBnClickedChkRotateZ();

	afx_msg void OnBnClickedChkUnitList();
	afx_msg void OnBnClickedChkObjList();

};
