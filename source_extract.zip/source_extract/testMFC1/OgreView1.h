// OgreView.h : interface of the COgreView class
//


#pragma once

#include "etsample.cpp"

//Use this define to signify OIS will be used as a DLL
//(so that dll import/export macros are in effect)
#define OIS_DYNAMIC_LIB
#include <OIS/OIS.h>

class COgreDoc;

class COgreView1 : public CView, public Ogre::FrameListener
{
	DemoETSM app;

protected: // create from serialization only
	COgreView1();
	DECLARE_DYNCREATE(COgreView1)

//// Attributes
//public:
//	COgreDoc* GetDocument() const;

// Operations
public:
	//OIS Input devices
	OIS::InputManager* mInputManager;
	OIS::Mouse*    mMouse;
	OIS::Keyboard* mKeyboard;
	OIS::JoyStick* mJoy;

	RaySceneQuery* raySceneQuery;

// 	SceneManager* mSceneMgr;
// 	CEGUI::Renderer* mGUIRenderer;
// 	bool mShutdownRequested;
// 	bool mUseBufferedInputKeys, mUseBufferedInputMouse, mInputTypeSwitchingOn;
	AnimationState *ani;

	std::deque<Vector3> mWalkList;
	float mWalkSpeed, mDistance;
	Vector3 mDestination, mDirection;
//	Node *mNode;

	RaySceneQuery *mRaySceneQuery;
	Ray mouseRay;
	SceneNode *mCurrentObject;
	int mCount;

//	bool mLMouseDown, mRMouseDown;


	bool m_bClick;
	CPoint m_ptPos;

	Ogre::Root *m_pRoot;
	Ogre::SceneManager *m_pSceneManager;
	Ogre::Camera *m_pCamera;
	Ogre::RenderWindow *m_pWindow;

	int mSceneDetailIndex ;
    Ogre::Real mMoveSpeed;
    Ogre::Degree mRotateSpeed;
	Ogre::Overlay* m_pDebugOverlay;

    Ogre::Vector3 mTranslateVector;
    Ogre::RenderWindow* mWindow;
    bool mStatsOn;
    bool mUseBufferedInputKeys, mUseBufferedInputMouse, mInputTypeSwitchingOn;
	unsigned int mNumScreenShots;
    float mMoveScale;
    Ogre::Degree mRotScale;
    // just to stop toggles flipping too fast
    Ogre::Real mTimeUntilNextToggle ;
    Ogre::Radian mRotX, mRotY;
    Ogre::TextureFilterOptions mFiltering;
    int mAniso;


	// ExampleApplication
	virtual void chooseSceneManager(void);
	virtual void createCamera(void);
	virtual void createFrameListener(void);
	virtual void createScene(void);    // pure virtual - this has to be overridden
	virtual void destroyScene(void);    // Optional to override this
	virtual void createViewports(void);


	// Ogre::FrameListener
	virtual	bool frameStarted(const Ogre::FrameEvent &evt);
	virtual	bool frameEnded(const Ogre::FrameEvent &evt);

	// ExampleFrameListener
	void moveCamera();

	void UpdateStats(void);
	void ShowDebugOverlay(bool show);


// Overrides
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// Implementation
public:
	virtual ~COgreView1();

#if 0
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	bool setup(void);
	afx_msg void OnPaint();
	virtual void OnInitialUpdate();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
};

#if 0
#ifndef _DEBUG  // debug version in OgreView.cpp
inline COgreDoc* COgreView::GetDocument() const
   { return reinterpret_cast<COgreDoc*>(m_pDocument); }
#endif
#endif
