#ifndef __BmpToOff_H__
#define __BmpToOff_H__

#include "CFileBMP.h"
#include <ddraw.h>

class BmpToOff
{
public:
	BmpToOff();
	~BmpToOff();

private:
	CFileBMP BMPFile;
	LPDIRECTDRAWSURFACE7 pDDSOff;

public:
	LPDIRECTDRAWSURFACE7 OpenFile(char *sFileName, LPDIRECTDRAW7 pDD
		, int MaxX=0, int MaxY=0);
};

#endif// __BmpToOff_H__