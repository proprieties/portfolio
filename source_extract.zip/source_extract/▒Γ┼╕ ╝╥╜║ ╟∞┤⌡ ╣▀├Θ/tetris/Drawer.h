#ifndef __Drawer_H__
#define __Drawer_H__

#include <windows.h>
#include <ctime>

class CreateMap;
class CreateToyGroup;

class DrawerAb
{
public:
	virtual bool Initialize(CreateMap *NewMap, CreateToyGroup *NewToyGroup, HWND hwndNew)=0;
	virtual void Destroy()=0;
	virtual void Drawing()=0;
};

class Drawer : public DrawerAb
{
private:
	CreateMap *Map;
	CreateToyGroup *ToyGroup;

	clock_t DrawStart;
	float DrawTime;

	HWND hwnd;
	HDC hdc, backdc;
	HBITMAP hBackBitmap;
	RECT rc;

public:
	void ReDrawNextMap();
	void Drawing();
	bool Initialize(CreateMap *NewMap, CreateToyGroup *NewToyGroup, HWND hwndNew);
	void Destroy();
	Drawer();
	~Drawer();
	void DrawNowToySet();
	void DrawNextToySet();
	void ReDrawMap();
	void ErasePrevToySet();
	void DrawBlock(int X, int Y, COLORREF color);
	void DrawMap();
};

#endif // __Drawer_H__
