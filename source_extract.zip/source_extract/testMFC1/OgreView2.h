// OgreView.h : interface of the COgreView class
//


#pragma once

/*
//Use this define to signify OIS will be used as a DLL
//(so that dll import/export macros are in effect)
#define OIS_DYNAMIC_LIB
#include <OIS/OIS.h>

#include <CEGUI.h>
#include <CEGUISystem.h>
#include <CEGUISchemeManager.h>
#include <OgreCEGUIRenderer.h>
*/

class COgreDoc;

class COgreView2 : public CView, public Ogre::FrameListener//, public OIS::KeyListener, public OIS::MouseListener
{
/*
	class MouseListener : public OIS::MouseListener
	{
	public:
		COgreView2 *view;
		MouseListener(COgreView2 *view) { this->view = view; }
		// OIS
		//----------------------------------------------------------------//
		bool mouseMoved( const OIS::MouseEvent &arg )
		{
			CEGUI::System::getSingleton().injectMouseMove( arg.state.X.rel, arg.state.Y.rel );

			Camera *mCamera = m_pCamera;

			// If we are dragging the left mouse button.
			if (mLMouseDown)
			{
				CEGUI::Point mousePos = CEGUI::MouseCursor::getSingleton().getPosition();
				Ray mouseRay = mCamera->getCameraToViewportRay(mousePos.d_x/float(arg.state.width),
					mousePos.d_y/float(arg.state.height));
				mRaySceneQuery->setRay(mouseRay);
				RaySceneQueryResult &result = mRaySceneQuery->execute();

				RaySceneQueryResult::iterator itr = result.begin();
				if (itr != result.end() && itr->worldFragment)
					mCurrentObject->setPosition(itr->worldFragment->singleIntersection);
			} // if
			else if (mRMouseDown) 	   // If we are dragging the right mouse button.
			{
				/ *
				Camera *cam1 = mSceneMgr->getCamera("PlayerCam2");
				cam1->rotate(Vector3(0.0f,0.1f,0.0001f),Radian(Real(0.01f)));
				cam1->roll(Radian(0.1f));
				* /

				mCamera->yaw(Degree(-arg.state.X.rel * 0.13/ *mRotateSpeed* /));
				mCamera->pitch(Degree(-arg.state.Y.rel * 0.13/ *mRotateSpeed* /));
			} // else if

			return true;
		}

		//----------------------------------------------------------------//
		bool mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id )
		{
			CEGUI::System::getSingleton().injectMouseButtonDown(convertOISMouseButtonToCegui(id));

			Camera *mCamera = m_pCamera;
			SceneManager *mSceneMgr = m_pSceneManager;

			// Left mouse button up
			if (id == OIS::MB_Left)
			{
				mLMouseDown = true;
				// ����Camera �κ���Mouse���Ǳ����������.
				CEGUI::Point mousePos = CEGUI::MouseCursor::getSingleton().getPosition();
				mouseRay = mCamera->getCameraToViewportRay(mousePos.d_x/float(arg.state.width),
					mousePos.d_y/float(arg.state.height));

				mRaySceneQuery->setRay( mouseRay );
				RaySceneQueryResult &result2 = mRaySceneQuery->execute();
				RaySceneQueryResult::iterator itr2 = result2.begin();

				if ( itr2 != result2.end() && itr2->worldFragment ) 
				{
					char name[16];
					sprintf( name, "Robot%d", mCount++ );
					Entity *ent = mSceneMgr->createEntity( name, "robot.mesh" );
					mCurrentObject = mSceneMgr->getRootSceneNode( )->createChildSceneNode(
						String(name) + "Node",
						itr2->worldFragment->singleIntersection );
					mCurrentObject->attachObject( ent );
					mCurrentObject->setScale( 0.1f, 0.1f, 0.1f );
					if (mCurrentObject)
						mCurrentObject->showBoundingBox(true);
				}
			} // if

			// Right mouse button up
			else if (id == OIS::MB_Right)
			{
				CEGUI::MouseCursor::getSingleton().show();
				mRMouseDown = true;
			} // else if

			return true;
		}

		//----------------------------------------------------------------//
		bool mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id )
		{
			CEGUI::System::getSingleton().injectMouseButtonUp(convertOISMouseButtonToCegui(id));

			// Left mouse button up
			if (id == OIS::MB_Left)
			{
				mLMouseDown = false;
				if (mCurrentObject)
					mCurrentObject->showBoundingBox(false);
			} // if

			// Right mouse button up
			else if (id == OIS::MB_Right)
			{
				CEGUI::MouseCursor::getSingleton().show();
				mRMouseDown = false;
			} // else if

			return true;
		}
	} mouseListener(this);

	class KeyListener : public OIS::KeyListener
	{
		COgreView2 *view;
	public:
		KeyListener(COgreView2 *view) { this->view = view; }
		//----------------------------------------------------------------//
		bool keyPressed( const OIS::KeyEvent &arg )
		{
			if( arg.key == OIS::KC_ESCAPE )
				mShutdownRequested = true;

			CEGUI::System::getSingleton().injectKeyDown( arg.key );
			CEGUI::System::getSingleton().injectChar( arg.text );
			return true;
		}

		//----------------------------------------------------------------//
		bool keyReleased( const OIS::KeyEvent &arg )
		{
			if( arg.key == OIS::KC_M )
				mMouse->setBuffered( !mMouse->buffered() );
			else if( arg.key == OIS::KC_K )
				mKeyboard->setBuffered( !mKeyboard->buffered() );

			CEGUI::System::getSingleton().injectKeyUp( arg.key );
			return true;
		}
	} keyListener;

	CEGUI::MouseButton convertOISMouseButtonToCegui(int buttonID)
	{
		switch (buttonID)
		{
		case 0: return CEGUI::LeftButton;
		case 1: return CEGUI::RightButton;
		case 2:	return CEGUI::MiddleButton;
		case 3: return CEGUI::X1Button;
		default: return CEGUI::LeftButton;
		}
	}
*/


protected: // create from serialization only
	COgreView2();
	DECLARE_DYNCREATE(COgreView2)

//// Attributes
//public:
//	COgreDoc* GetDocument() const;

// Operations
public:
	//OIS Input devices
	OIS::InputManager* mInputManager;
	OIS::Mouse*    mMouse;
	OIS::Keyboard* mKeyboard;
	OIS::JoyStick* mJoy;

	RaySceneQuery* raySceneQuery;

// 	SceneManager* mSceneMgr;
// 	CEGUI::Renderer* mGUIRenderer;
 	bool mShutdownRequested;
// 	bool mUseBufferedInputKeys, mUseBufferedInputMouse, mInputTypeSwitchingOn;
	AnimationState *ani;

	std::deque<Vector3> mWalkList;
	float mWalkSpeed, mDistance;
	Vector3 mDestination, mDirection;
//	Node *mNode;

	RaySceneQuery *mRaySceneQuery;
	Ray mouseRay;
	SceneNode *mCurrentObject;
	int mCount;

	bool mLMouseDown, mRMouseDown;


	bool m_bClick;
	CPoint m_ptPos;

	Ogre::Root *m_pRoot;
	Ogre::SceneManager *m_pSceneManager;
	Ogre::Camera *m_pCamera;
	Ogre::RenderWindow *m_pWindow;

	int mSceneDetailIndex ;
    Ogre::Real mMoveSpeed;
    Ogre::Degree mRotateSpeed;
	Ogre::Overlay* m_pDebugOverlay;

    Ogre::Vector3 mTranslateVector;
    Ogre::RenderWindow* mWindow;
    bool mStatsOn;
    bool mUseBufferedInputKeys, mUseBufferedInputMouse, mInputTypeSwitchingOn;
	unsigned int mNumScreenShots;
    float mMoveScale;
    Ogre::Degree mRotScale;
    // just to stop toggles flipping too fast
    Ogre::Real mTimeUntilNextToggle ;
    Ogre::Radian mRotX, mRotY;
    Ogre::TextureFilterOptions mFiltering;
    int mAniso;


	// ExampleApplication
	virtual void chooseSceneManager(void);
	virtual void createCamera(void);
	virtual void createFrameListener(void);
	virtual void createScene(void);    // pure virtual - this has to be overridden
	virtual void destroyScene(void);    // Optional to override this
	virtual void createViewports(void);


	// Ogre::FrameListener
	virtual	bool frameStarted(const Ogre::FrameEvent &evt);
	virtual	bool frameEnded(const Ogre::FrameEvent &evt);

	// ExampleFrameListener
	void moveCamera();

	void UpdateStats(void);
	void ShowDebugOverlay(bool show);


// Overrides
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// Implementation
public:
	virtual ~COgreView2();

#if 0
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	bool setup(void);
	afx_msg void OnPaint();
	virtual void OnInitialUpdate();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
};

#if 0
#ifndef _DEBUG  // debug version in OgreView.cpp
inline COgreDoc* COgreView::GetDocument() const
   { return reinterpret_cast<COgreDoc*>(m_pDocument); }
#endif
#endif
