#pragma once

class OgreBaseApp : public ExampleApplication
{
	Camera*		mCameraSuv[5];
	Viewport*	mViwportSuv[5];
private:
	CEGUI::OgreCEGUIRenderer* mGUIRenderer;
	CEGUI::System* mGUISystem;
	SceneNode *mFountainNode;
public:
	OgreBaseApp();
	~OgreBaseApp();

protected:

	virtual void createCamera(void);
	virtual bool configure(void);
	virtual void createViewports(void);
	virtual void chooseSceneManager(void);
	// Just override the mandatory create scene method
	virtual void createScene(void);
	

	// Create new frame listener
	void createFrameListener(void);

	void setupEventHandlers(void);
	bool handleQuit(const CEGUI::EventArgs& e);
};